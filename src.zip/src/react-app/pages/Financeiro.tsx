"use client";

import React, { useEffect, useMemo, useState } from "react";
import { useAppAuth } from "@/contexts/AppAuthContext";
import { Button } from "@/react-app/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/react-app/components/ui/card";
import { Input } from "@/react-app/components/ui/input";
import { Label } from "@/react-app/components/ui/label";
import { Badge } from "@/react-app/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/react-app/components/ui/dialog";
import {
  Calculator,
  FileText,
  Check,
  Clock,
  AlertTriangle,
  CreditCard,
  Image,
  MessageSquare,
  Send,
  ShieldAlert,
  Loader2,
  Building2,
  RefreshCw,
  Plus,
  Calendar,
  Filter,
  Download,
  FileSpreadsheet,
  Brain,
  Siren,
  TrendingUp,
} from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/react-app/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/react-app/components/ui/select";
import { Textarea } from "@/react-app/components/ui/textarea";

export interface Lancamento {
  id: string;
  empresa_id: string;
  data_pedido: string;
  fornecedor: string;
  categoria: string;
  valor_previsto: number;
  is_boleto_recebido: boolean;
  valor_real: number | null;
  vencimento_real: string | null;
  status_pagamento: "pendente" | "pago";
  data_pagamento: string | null;
  anexo_url: string | null;
  comprovante_url: string | null;
  observacao: string | null;
  is_manual: boolean;
  criado_em: string;
}

export const CATEGORIAS = [
  "Insumos e Ingredientes",
  "Embalagens",
  "Bebidas",
  "Materiais de Limpeza",
  "Equipamentos",
  "Serviços Terceirizados",
  "Impostos e Taxas",
  "Marketing e Publicidade",
  "Folha de Pagamento",
  "Aluguel e Condomínio",
  "Energia Elétrica",
  "Água",
  "Internet e Telefone",
  "Manutenção",
  "Outros",
] as const;

type StatusLancamento = "Aguardando Boleto" | "A Pagar" | "Atrasado" | "Pago";
type StatusFilter = "todos" | StatusLancamento;
type DdaFilter = "pendente" | "pago" | "todos";

interface Fornecedor {
  id: string | number;
  nome_fantasia: string;
  telefone_whatsapp: string;
}

interface Empresa {
  id: string | number;
  limite_aprovacao_pagamento: number;
  whatsapp_admin: string;
}

interface BoletoDDA {
  id: string | number;
  fornecedor_nome: string;
  valor: number;
  vencimento: string;
  codigo_barras: string;
  linha_digitavel: string;
  status_pagamento: "pendente" | "pago" | "cancelado";
  data_pagamento: string | null;
}

interface ManualFormState {
  fornecedor: string;
  categoria: string;
  valor: string;
  descricao: string;
  data_pagamento: string;
  is_pago: boolean;
}

interface BoletoFormState {
  valor_real: string;
  vencimento_real: string;
}

interface DashboardResumo {
  pagarHoje: number;
  pagar7Dias: number;
  pagarAtrasado: number;
  totalPendente: number;
  totalPago: number;
  totalLancamentos: number;
  totalBoletos: number;
  totalNotas: number;
  semBoleto: number;
  divergencias: number;
  ticketMedioSaida: number;
}

interface InsightAlert {
  id: string;
  title: string;
  description: string;
  level: "critico" | "atencao" | "ok";
  value?: number;
  href?: string;
}

interface FinanceiroInsights {
  summary: string;
  deterministicSummary?: string;
  alerts: InsightAlert[];
  actions: Array<{ title: string; description: string; href: string }>;
  topCategorias: Array<{ categoria: string; total: number }>;
  aiEnabled: boolean;
}

function toMidnight(date: Date): Date {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
}

function isDatePast(dateString: string | null): boolean {
  if (!dateString) return false;
  const hoje = toMidnight(new Date());
  const data = toMidnight(new Date(dateString));
  return data < hoje;
}

export function calcularStatus(lancamento: Lancamento): StatusLancamento {
  if (lancamento.status_pagamento === "pago" || lancamento.data_pagamento) {
    return "Pago";
  }

  if (!lancamento.is_boleto_recebido) {
    return "Aguardando Boleto";
  }

  if (lancamento.vencimento_real && isDatePast(lancamento.vencimento_real)) {
    return "Atrasado";
  }

  return "A Pagar";
}

export default function FinanceiroPage() {
  const { localUser } = useAppAuth();

  const [lancamentos, setLancamentos] = useState<Lancamento[]>([]);
  const [fornecedores, setFornecedores] = useState<Fornecedor[]>([]);
  const [empresa, setEmpresa] = useState<Empresa | null>(null);
  const [dashboardResumo, setDashboardResumo] = useState<DashboardResumo | null>(null);
  const [insights, setInsights] = useState<FinanceiroInsights | null>(null);
  const [loadingInsights, setLoadingInsights] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [filter, setFilter] = useState<StatusFilter>("todos");
  const [selectedLancamento, setSelectedLancamento] = useState<Lancamento | null>(null);
  const [saving, setSaving] = useState<boolean>(false);

  const [payDialogOpen, setPayDialogOpen] = useState<boolean>(false);
  const [payingLancamento, setPayingLancamento] = useState<Lancamento | null>(null);
  const [comprovanteUrl, setComprovanteUrl] = useState<string | null>(null);
  const [uploadingComprovante, setUploadingComprovante] = useState<boolean>(false);

  const [boletosDDA, setBoletosDDA] = useState<BoletoDDA[]>([]);
  const [loadingDDA, setLoadingDDA] = useState<boolean>(false);
  const [ddaFilter, setDdaFilter] = useState<DdaFilter>("pendente");

  const [dataInicio, setDataInicio] = useState<string>("");
  const [dataFim, setDataFim] = useState<string>("");

  const [manualDialogOpen, setManualDialogOpen] = useState<boolean>(false);
  const [savingManual, setSavingManual] = useState<boolean>(false);
  const [manualForm, setManualForm] = useState<ManualFormState>({
    fornecedor: "",
    categoria: "",
    valor: "",
    descricao: "",
    data_pagamento: "",
    is_pago: false,
  });

  const [formData, setFormData] = useState<BoletoFormState>({
    valor_real: "",
    vencimento_real: "",
  });

  const empresaId =
    localUser?.empresa_id ||
    localStorage.getItem("empresa_id") ||
    localStorage.getItem("pId") ||
    localStorage.getItem("pizzariaId") ||
    "";

  const userEmail = localUser?.email || localStorage.getItem("userEmail") || "";

  function getAuthHeaders(extra?: Record<string, string>): HeadersInit {
    return {
      "x-empresa-id": empresaId,
      "x-user-email": userEmail,
      ...extra,
    };
  }

  useEffect(() => {
    void fetchData();
    void fetchBoletosDDA();
    void fetchDashboardAndInsights();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [empresaId, userEmail]);

  useEffect(() => {
    void fetchBoletosDDA();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ddaFilter]);

  async function fetchData(): Promise<void> {
    try {
      setLoading(true);

      const [lancRes, fornRes, empRes] = await Promise.all([
        fetch("/api/lancamentos", {
          headers: getAuthHeaders(),
        }),
        fetch("/api/fornecedores", {
          headers: getAuthHeaders(),
        }),
        fetch("/api/empresa-config", {
          headers: getAuthHeaders(),
        }),
      ]);

      if (lancRes.ok) {
        const data = (await lancRes.json()) as Lancamento[];
        setLancamentos(Array.isArray(data) ? data : []);
      }

      if (fornRes.ok) {
        const data = (await fornRes.json()) as Fornecedor[];
        setFornecedores(Array.isArray(data) ? data : []);
      }

      if (empRes.ok) {
        const data = (await empRes.json()) as Empresa;
        setEmpresa(data ?? null);
      }
    } catch (error) {
      console.error("Erro ao carregar dados financeiros:", error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchDashboardAndInsights(): Promise<void> {
    try {
      setLoadingInsights(true);

      const [dashboardRes, insightsRes] = await Promise.all([
        fetch("/api/financeiro/dashboard", { headers: getAuthHeaders() }),
        fetch("/api/financeiro/insights", { headers: getAuthHeaders() }),
      ]);

      if (dashboardRes.ok) {
        const data = (await dashboardRes.json()) as DashboardResumo;
        setDashboardResumo(data);
      }

      if (insightsRes.ok) {
        const data = (await insightsRes.json()) as FinanceiroInsights;
        setInsights(data);
      }
    } catch (error) {
      console.error("Erro ao carregar resumo/insights financeiros:", error);
    } finally {
      setLoadingInsights(false);
    }
  }

  async function fetchBoletosDDA(): Promise<void> {
    setLoadingDDA(true);

    try {
      const statusParam = ddaFilter !== "todos" ? `?status=${ddaFilter}` : "";
      const res = await fetch(`/api/boletos-dda${statusParam}`, {
        headers: getAuthHeaders(),
      });

      if (res.ok) {
        const data = (await res.json()) as BoletoDDA[];
        setBoletosDDA(Array.isArray(data) ? data : []);
      } else {
        setBoletosDDA([]);
      }
    } catch (error) {
      console.error("Erro ao carregar DDA:", error);
      setBoletosDDA([]);
    } finally {
      setLoadingDDA(false);
    }
  }

  async function handleSaveManual(): Promise<void> {
    if (!manualForm.fornecedor || !manualForm.categoria || !manualForm.valor) {
      alert("Preencha todos os campos obrigatórios");
      return;
    }

    setSavingManual(true);

    try {
      const valor = Number.parseFloat(manualForm.valor);

      const response = await fetch("/api/lancamentos", {
        method: "POST",
        headers: getAuthHeaders({
          "Content-Type": "application/json",
        }),
        body: JSON.stringify({
          data_pedido: new Date().toISOString().split("T")[0],
          fornecedor: manualForm.fornecedor,
          categoria: manualForm.categoria,
          valor_previsto: valor,
          is_boleto_recebido: true,
          valor_real: valor,
          vencimento_real: manualForm.data_pagamento || new Date().toISOString().split("T")[0],
          data_pagamento: manualForm.is_pago
            ? manualForm.data_pagamento || new Date().toISOString().split("T")[0]
            : null,
          observacao: manualForm.descricao,
          is_manual: true,
        }),
      });

      if (!response.ok) {
        throw new Error("Erro ao salvar lançamento manual");
      }

      alert("Lançamento manual registrado!");
      setManualDialogOpen(false);
      setManualForm({
        fornecedor: "",
        categoria: "",
        valor: "",
        descricao: "",
        data_pagamento: "",
        is_pago: false,
      });

      await Promise.all([fetchData(), fetchDashboardAndInsights()]);
    } catch (error) {
      console.error("Erro ao salvar lançamento manual:", error);
      alert("Erro ao registrar lançamento");
    } finally {
      setSavingManual(false);
    }
  }

  async function handlePagarDDA(boleto: BoletoDDA): Promise<void> {
    const confirmado = window.confirm(
      `Confirmar pagamento de ${formatCurrency(boleto.valor)} para ${boleto.fornecedor_nome}?`
    );

    if (!confirmado) return;

    try {
      const response = await fetch(`/api/boletos-dda/${boleto.id}`, {
        method: "PATCH",
        headers: getAuthHeaders({
          "Content-Type": "application/json",
        }),
        body: JSON.stringify({
          status_pagamento: "pago",
          data_pagamento: new Date().toISOString().split("T")[0],
        }),
      });

      if (!response.ok) {
        throw new Error("Falha ao registrar pagamento do DDA");
      }

      alert("Pagamento registrado!");
      await Promise.all([fetchBoletosDDA(), fetchData(), fetchDashboardAndInsights()]);
    } catch (error) {
      console.error("Erro ao pagar DDA:", error);
      alert("Erro ao registrar pagamento");
    }
  }

  function getFornecedorWhatsApp(fornecedorNome: string): string {
    const fornecedor = fornecedores.find(
      (f) => f.nome_fantasia.toLowerCase() === fornecedorNome.toLowerCase()
    );

    return fornecedor?.telefone_whatsapp?.replace(/\D/g, "") || "";
  }

  function handleDarBaixa(lancamento: Lancamento): void {
    setSelectedLancamento(lancamento);
    setFormData({
      valor_real: lancamento.valor_real?.toString() || lancamento.valor_previsto.toString(),
      vencimento_real: lancamento.vencimento_real || "",
    });
  }

  async function handleSaveBoleto(): Promise<void> {
    if (!selectedLancamento) return;

    setSaving(true);

    try {
      const response = await fetch(`/api/lancamentos/${selectedLancamento.id}`, {
        method: "PATCH",
        headers: getAuthHeaders({
          "Content-Type": "application/json",
        }),
        body: JSON.stringify({
          is_boleto_recebido: true,
          valor_real: Number.parseFloat(formData.valor_real),
          vencimento_real: formData.vencimento_real,
        }),
      });

      if (!response.ok) {
        throw new Error("Falha ao registrar boleto");
      }

      alert("Boleto registrado com sucesso!");
      setSelectedLancamento(null);

      await Promise.all([fetchData(), fetchDashboardAndInsights()]);
    } catch (error) {
      console.error("Erro ao salvar boleto:", error);
      alert("Erro ao registrar boleto");
    } finally {
      setSaving(false);
    }
  }

  function handleOpenPayDialog(lancamento: Lancamento): void {
    setPayingLancamento(lancamento);
    setComprovanteUrl(null);
    setPayDialogOpen(true);
  }

  async function handleUploadComprovante(file: File): Promise<void> {
    setUploadingComprovante(true);

    try {
      const uploadData = new FormData();
      uploadData.append("file", file);
      uploadData.append("type", "comprovante");

      const res = await fetch("/api/upload", {
        method: "POST",
        headers: getAuthHeaders(),
        body: uploadData,
      });

      if (!res.ok) {
        throw new Error("Falha no upload do comprovante");
      }

      const data = (await res.json()) as { url?: string };
      setComprovanteUrl(data.url || null);
    } catch (error) {
      console.error("Erro ao fazer upload do comprovante:", error);
      alert("Erro ao enviar comprovante");
    } finally {
      setUploadingComprovante(false);
    }
  }

  async function handlePagar(): Promise<void> {
    if (!payingLancamento) return;

    setSaving(true);

    try {
      const response = await fetch(`/api/lancamentos/${payingLancamento.id}`, {
        method: "PATCH",
        headers: getAuthHeaders({
          "Content-Type": "application/json",
        }),
        body: JSON.stringify({
          data_pagamento: new Date().toISOString().split("T")[0],
          comprovante_url: comprovanteUrl,
        }),
      });

      if (!response.ok) {
        throw new Error("Falha ao registrar pagamento");
      }

      alert("Pagamento registrado!");
      setPayDialogOpen(false);
      setPayingLancamento(null);

      await Promise.all([fetchData(), fetchDashboardAndInsights()]);
    } catch (error) {
      console.error("Erro ao pagar lançamento:", error);
      alert("Erro ao registrar pagamento");
    } finally {
      setSaving(false);
    }
  }

  function formatCurrency(value: number | null): string {
    if (value === null) return "-";

    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);
  }

  function formatDate(date: string | null): string {
    if (!date) return "-";
    return new Date(date).toLocaleDateString("pt-BR");
  }

  function getInsightLevelClasses(level: InsightAlert["level"]): string {
    if (level === "critico") return "border-red-200 bg-red-50 text-red-700";
    if (level === "atencao") return "border-amber-200 bg-amber-50 text-amber-700";
    return "border-emerald-200 bg-emerald-50 text-emerald-700";
  }

  function generateWhatsAppDivergencia(lancamento: Lancamento): string {
    const phone = getFornecedorWhatsApp(lancamento.fornecedor);
    const msg = `Olá ${lancamento.fornecedor}, identificamos uma divergência. O pedido foi fechado em ${formatCurrency(
      lancamento.valor_previsto
    )}, mas o boleto chegou no valor de ${formatCurrency(
      lancamento.valor_real
    )}. Podemos corrigir?`;

    return `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
  }

  function generateWhatsAppComprovante(lancamento: Lancamento): string {
    const phone = getFornecedorWhatsApp(lancamento.fornecedor);
    const msg = `Olá ${lancamento.fornecedor}, segue o comprovante de pagamento referente ao pedido de ${formatDate(
      lancamento.data_pedido
    )}. Valor: ${formatCurrency(lancamento.valor_real || lancamento.valor_previsto)}. Obrigado!`;

    return `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
  }

  function generateWhatsAppAprovacao(lancamento: Lancamento): string {
    const phone = empresa?.whatsapp_admin?.replace(/\D/g, "") || "";
    const msg = `Aprovação pendente: Boleto de ${lancamento.fornecedor}, valor ${formatCurrency(
      lancamento.valor_real || lancamento.valor_previsto
    )}, vencimento ${formatDate(
      lancamento.vencimento_real
    )}. Responda SIM para liberar o pagamento no sistema.`;

    return `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
  }

  function hasDivergencia(lancamento: Lancamento): boolean {
    if (lancamento.valor_real === null || lancamento.valor_previsto === null) {
      return false;
    }

    const diff = Math.abs(lancamento.valor_real - lancamento.valor_previsto);
    const tolerance = lancamento.valor_previsto * 0.01;
    return diff > tolerance;
  }

  function needsApproval(lancamento: Lancamento): boolean {
    const valor = lancamento.valor_real || lancamento.valor_previsto;
    const limite = empresa?.limite_aprovacao_pagamento || 5000;
    return valor > limite;
  }

  function getStatusBadge(lancamento: Lancamento): React.ReactNode {
    const status = calcularStatus(lancamento);

    const styles: Record<StatusLancamento, string> = {
      "Aguardando Boleto": "bg-gray-100 text-gray-700 border-gray-200",
      "A Pagar": "bg-blue-100 text-blue-700 border-blue-200",
      Atrasado: "bg-red-100 text-red-700 border-red-200",
      Pago: "bg-green-100 text-green-700 border-green-200",
    };

    const icons: Record<StatusLancamento, React.ReactNode> = {
      "Aguardando Boleto": <FileText className="w-3 h-3" />,
      "A Pagar": <Clock className="w-3 h-3" />,
      Atrasado: <AlertTriangle className="w-3 h-3" />,
      Pago: <Check className="w-3 h-3" />,
    };

    return (
      <Badge variant="outline" className={`${styles[status]} flex items-center gap-1`}>
        {icons[status]}
        {status}
      </Badge>
    );
  }

  function limparFiltroData(): void {
    setDataInicio("");
    setDataFim("");
  }

  const lancamentosFiltradosPorData = useMemo(() => {
    return lancamentos.filter((l) => {
      if (!dataInicio && !dataFim) return true;

      const dataRef = l.vencimento_real || l.data_pedido;
      if (!dataRef) return true;

      if (dataInicio && dataRef < dataInicio) return false;
      if (dataFim && dataRef > dataFim) return false;

      return true;
    });
  }, [lancamentos, dataInicio, dataFim]);

  const filteredLancamentos = useMemo(() => {
    return lancamentosFiltradosPorData.filter((l) => {
      if (filter === "todos") return true;
      return calcularStatus(l) === filter;
    });
  }, [lancamentosFiltradosPorData, filter]);

  const totais = useMemo(() => {
    return {
      aguardando: lancamentosFiltradosPorData.filter(
        (l) => calcularStatus(l) === "Aguardando Boleto"
      ).length,
      aPagar: lancamentosFiltradosPorData.filter((l) => calcularStatus(l) === "A Pagar").length,
      atrasado: lancamentosFiltradosPorData.filter((l) => calcularStatus(l) === "Atrasado").length,
      pago: lancamentosFiltradosPorData.filter((l) => calcularStatus(l) === "Pago").length,
    };
  }, [lancamentosFiltradosPorData]);

  const totaisValores = useMemo(() => {
    return {
      geral: lancamentosFiltradosPorData.reduce(
        (acc, l) => acc + (l.valor_real || l.valor_previsto),
        0
      ),
      aguardando: lancamentosFiltradosPorData
        .filter((l) => calcularStatus(l) === "Aguardando Boleto")
        .reduce((acc, l) => acc + l.valor_previsto, 0),
      aPagar: lancamentosFiltradosPorData
        .filter((l) => calcularStatus(l) === "A Pagar")
        .reduce((acc, l) => acc + (l.valor_real || l.valor_previsto), 0),
      atrasado: lancamentosFiltradosPorData
        .filter((l) => calcularStatus(l) === "Atrasado")
        .reduce((acc, l) => acc + (l.valor_real || l.valor_previsto), 0),
      pago: lancamentosFiltradosPorData
        .filter((l) => calcularStatus(l) === "Pago")
        .reduce((acc, l) => acc + (l.valor_real || l.valor_previsto), 0),
    };
  }, [lancamentosFiltradosPorData]);

  const divergenciaModal = useMemo(() => {
    if (!selectedLancamento || !formData.valor_real) return false;

    const valorDigitado = Number.parseFloat(formData.valor_real || "0");
    const diferenca = Math.abs(valorDigitado - selectedLancamento.valor_previsto);
    const tolerancia = selectedLancamento.valor_previsto * 0.01;

    return diferenca > tolerancia;
  }, [selectedLancamento, formData.valor_real]);

  function exportarPDF(): void {
    const doc = new jsPDF();
    const dataAtual = new Date().toLocaleDateString("pt-BR");

    doc.setFontSize(18);
    doc.setTextColor(234, 88, 12);
    doc.text("Pappi Gestor Inteligente", 14, 20);

    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text("Relatório Financeiro", 14, 30);

    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(`Gerado em: ${dataAtual}`, 14, 38);

    if (dataInicio || dataFim) {
      doc.text(`Período: ${dataInicio || "início"} a ${dataFim || "fim"}`, 14, 44);
    }

    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0);
    doc.text("Resumo:", 14, 55);

    doc.setFontSize(10);
    doc.text(`Total Geral: ${formatCurrency(totaisValores.geral)}`, 14, 62);
    doc.text(`A Pagar: ${formatCurrency(totaisValores.aPagar)} (${totais.aPagar})`, 14, 68);
    doc.text(`Atrasados: ${formatCurrency(totaisValores.atrasado)} (${totais.atrasado})`, 14, 74);
    doc.text(`Pagos: ${formatCurrency(totaisValores.pago)} (${totais.pago})`, 14, 80);

    const tableData = filteredLancamentos.map((l) => [
      formatDate(l.data_pedido),
      l.fornecedor,
      l.categoria,
      formatCurrency(l.valor_previsto),
      formatCurrency(l.valor_real),
      formatDate(l.vencimento_real),
      calcularStatus(l),
      l.data_pagamento ? formatDate(l.data_pagamento) : "-",
    ]);

    autoTable(doc, {
      startY: 90,
      head: [["Data", "Fornecedor", "Categoria", "Previsto", "Real", "Vencimento", "Status", "Pago em"]],
      body: tableData,
      styles: { fontSize: 8, cellPadding: 2 },
      headStyles: { fillColor: [234, 88, 12], textColor: 255 },
      alternateRowStyles: { fillColor: [255, 247, 237] },
      columnStyles: {
        0: { cellWidth: 20 },
        1: { cellWidth: 35 },
        2: { cellWidth: 25 },
        3: { cellWidth: 22 },
        4: { cellWidth: 22 },
        5: { cellWidth: 20 },
        6: { cellWidth: 22 },
        7: { cellWidth: 20 },
      },
    });

    doc.save(`financeiro_${dataAtual.replace(/\//g, "-")}.pdf`);
  }

  function exportarExcel(): void {
    const dataAtual = new Date().toLocaleDateString("pt-BR");

    const dados = filteredLancamentos.map((l) => ({
      "Data Pedido": formatDate(l.data_pedido),
      Fornecedor: l.fornecedor,
      Categoria: l.categoria,
      "Valor Previsto": l.valor_previsto,
      "Valor Real": l.valor_real || "",
      Vencimento: formatDate(l.vencimento_real),
      Status: calcularStatus(l),
      "Data Pagamento": l.data_pagamento ? formatDate(l.data_pagamento) : "",
    }));

    const ws = XLSX.utils.json_to_sheet(dados);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Financeiro");

    const resumo = [
      {
        Métrica: "Total Geral",
        Valor: totaisValores.geral,
        Quantidade: lancamentosFiltradosPorData.length,
      },
      {
        Métrica: "Aguardando Boleto",
        Valor: totaisValores.aguardando,
        Quantidade: totais.aguardando,
      },
      {
        Métrica: "A Pagar",
        Valor: totaisValores.aPagar,
        Quantidade: totais.aPagar,
      },
      {
        Métrica: "Atrasado",
        Valor: totaisValores.atrasado,
        Quantidade: totais.atrasado,
      },
      {
        Métrica: "Pago",
        Valor: totaisValores.pago,
        Quantidade: totais.pago,
      },
    ];

    const wsResumo = XLSX.utils.json_to_sheet(resumo);
    XLSX.utils.book_append_sheet(wb, wsResumo, "Resumo");

    XLSX.writeFile(wb, `financeiro_${dataAtual.replace(/\//g, "-")}.xlsx`);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-orange-600" />
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Controle Financeiro</h1>
        <p className="text-sm sm:text-base text-gray-600">
          Gerencie boletos, pagamentos e divergências
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-5 mb-6">
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Pendente</p>
            <p className="mt-1 text-lg font-semibold">{formatCurrency(dashboardResumo?.totalPendente ?? 0)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Atrasado</p>
            <p className="mt-1 text-lg font-semibold text-red-600">{formatCurrency(dashboardResumo?.pagarAtrasado ?? 0)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">7 dias</p>
            <p className="mt-1 text-lg font-semibold">{formatCurrency(dashboardResumo?.pagar7Dias ?? 0)}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Sem boleto</p>
            <p className="mt-1 text-lg font-semibold">{dashboardResumo?.semBoleto ?? 0}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Divergências</p>
            <p className="mt-1 text-lg font-semibold">{dashboardResumo?.divergencias ?? 0}</p>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-6 border-orange-200 bg-gradient-to-r from-orange-50 via-white to-pink-50">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-3">
            <div>
              <CardTitle className="flex items-center gap-2 text-base">
                <Brain className="h-4 w-4 text-orange-500" />
                Análise inteligente do financeiro
              </CardTitle>
              <p className="mt-1 text-sm text-muted-foreground">
                Regras automáticas no backend e resumo de IA quando Gemini estiver configurado.
              </p>
            </div>
            {loadingInsights ? <Loader2 className="h-4 w-4 animate-spin text-orange-500" /> : null}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-xl border border-orange-100 bg-white/80 p-4 text-sm leading-6">
            {insights?.summary || "Ainda não há análise disponível para esta empresa."}
          </div>

          <div className="grid gap-3 md:grid-cols-3">
            {(insights?.alerts || []).slice(0, 3).map((alerta) => (
              <div key={alerta.id} className={`rounded-xl border p-3 ${getInsightLevelClasses(alerta.level)}`}>
                <div className="mb-1 flex items-center gap-2 font-medium">
                  {alerta.level === "critico" ? <Siren className="h-4 w-4" /> : <TrendingUp className="h-4 w-4" />}
                  <span>{alerta.title}</span>
                </div>
                <p className="text-xs leading-5 opacity-90">{alerta.description}</p>
              </div>
            ))}
          </div>

          {insights?.topCategorias?.length ? (
            <div className="rounded-xl border bg-white/80 p-4">
              <p className="mb-2 text-sm font-medium">Categorias com maior peso</p>
              <div className="flex flex-wrap gap-2">
                {insights.topCategorias.map((item) => (
                  <Badge key={item.categoria} variant="secondary">
                    {item.categoria}: {formatCurrency(item.total)}
                  </Badge>
                ))}
              </div>
            </div>
          ) : null}
        </CardContent>
      </Card>

      <Tabs defaultValue="provisoes" className="mb-6">
        <TabsList className="grid w-full max-w-xs sm:max-w-md grid-cols-2">
          <TabsTrigger value="provisoes" className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Provisões
          </TabsTrigger>
          <TabsTrigger value="dda" className="flex items-center gap-2">
            <Building2 className="w-4 h-4" />
            Entrada DDA
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dda" className="mt-6">
          <Card className="mb-6">
            <CardHeader className="border-b bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-t-xl">
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Building2 className="w-5 h-5" />
                  Boletos DDA (Débito Direto Autorizado)
                </div>

                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => void fetchBoletosDDA()}
                  disabled={loadingDDA}
                  className="bg-white/20 hover:bg-white/30 text-white border-0"
                >
                  <RefreshCw className={`w-4 h-4 mr-1 ${loadingDDA ? "animate-spin" : ""}`} />
                  Atualizar
                </Button>
              </CardTitle>
            </CardHeader>

            <CardContent className="pt-6">
              <div className="flex gap-2 mb-6">
                <Button
                  size="sm"
                  variant={ddaFilter === "pendente" ? "default" : "outline"}
                  onClick={() => setDdaFilter("pendente")}
                  className={ddaFilter === "pendente" ? "bg-indigo-600" : ""}
                >
                  Pendentes
                </Button>

                <Button
                  size="sm"
                  variant={ddaFilter === "pago" ? "default" : "outline"}
                  onClick={() => setDdaFilter("pago")}
                  className={ddaFilter === "pago" ? "bg-green-600" : ""}
                >
                  Pagos
                </Button>

                <Button
                  size="sm"
                  variant={ddaFilter === "todos" ? "default" : "outline"}
                  onClick={() => setDdaFilter("todos")}
                >
                  Todos
                </Button>
              </div>

              {loadingDDA ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
                </div>
              ) : boletosDDA.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <Building2 className="w-16 h-16 mx-auto mb-4 opacity-30" />
                  <p className="font-medium">Nenhum boleto DDA encontrado</p>
                  <p className="text-sm mt-1">
                    Os boletos do banco aparecerão aqui automaticamente quando integrados ao seu
                    sistema bancário.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {boletosDDA.map((boleto) => {
                    const vencido =
                      boleto.status_pagamento !== "pago" && isDatePast(boleto.vencimento);

                    return (
                      <div
                        key={boleto.id}
                        className={`p-4 rounded-lg border ${
                          boleto.status_pagamento === "pago"
                            ? "bg-green-50 border-green-200"
                            : vencido
                            ? "bg-red-50 border-red-200"
                            : "bg-white border-gray-200"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-semibold text-gray-800">{boleto.fornecedor_nome}</h4>
                            <p className="text-sm text-gray-500">
                              Vencimento: {formatDate(boleto.vencimento)}
                            </p>
                            <p className="text-xs text-gray-400 mt-1 font-mono">
                              {boleto.linha_digitavel || boleto.codigo_barras}
                            </p>
                          </div>

                          <div className="text-right">
                            <p className="text-lg font-bold text-gray-800">
                              {formatCurrency(boleto.valor)}
                            </p>

                            {boleto.status_pagamento === "pago" ? (
                              <Badge className="bg-green-100 text-green-700 border-green-200">
                                <Check className="w-3 h-3 mr-1" />
                                Pago{" "}
                                {boleto.data_pagamento &&
                                  `em ${formatDate(boleto.data_pagamento)}`}
                              </Badge>
                            ) : vencido ? (
                              <Badge className="bg-red-100 text-red-700 border-red-200">
                                <AlertTriangle className="w-3 h-3 mr-1" />
                                Vencido
                              </Badge>
                            ) : (
                              <Button
                                size="sm"
                                onClick={() => void handlePagarDDA(boleto)}
                                className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                              >
                                <CreditCard className="w-4 h-4 mr-1" />
                                Pagar
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="provisoes" className="mt-6">
          <Dialog open={manualDialogOpen} onOpenChange={setManualDialogOpen}>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Plus className="w-5 h-5 text-orange-600" />
                  Lançamento Manual
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-4 mt-4">
                <p className="text-sm text-gray-500">
                  Use para registrar pagamentos sem provisão: PIX, pagamentos avulsos, custos
                  extras, etc.
                </p>

                <div className="space-y-2">
                  <Label>Fornecedor / Descrição *</Label>
                  <Input
                    value={manualForm.fornecedor}
                    onChange={(e) =>
                      setManualForm({ ...manualForm, fornecedor: e.target.value })
                    }
                    placeholder="Ex: Mercado Livre, Conta de Luz, PIX João..."
                  />
                </div>

                <div className="space-y-2">
                  <Label>Categoria *</Label>
                  <Select
                    value={manualForm.categoria}
                    onValueChange={(value) =>
                      setManualForm({ ...manualForm, categoria: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIAS.map((cat) => (
                        <SelectItem key={cat} value={cat}>
                          {cat}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Valor (R$) *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    value={manualForm.valor}
                    onChange={(e) => setManualForm({ ...manualForm, valor: e.target.value })}
                    placeholder="0,00"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Observação</Label>
                  <Textarea
                    value={manualForm.descricao}
                    onChange={(e) =>
                      setManualForm({ ...manualForm, descricao: e.target.value })
                    }
                    placeholder="Detalhes do pagamento..."
                    rows={2}
                  />
                </div>

                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <input
                    type="checkbox"
                    id="is_pago"
                    checked={manualForm.is_pago}
                    onChange={(e) =>
                      setManualForm({ ...manualForm, is_pago: e.target.checked })
                    }
                    className="w-4 h-4 text-green-600 rounded"
                  />
                  <Label htmlFor="is_pago" className="cursor-pointer">
                    Já foi pago
                  </Label>
                </div>

                {manualForm.is_pago && (
                  <div className="space-y-2">
                    <Label>Data do Pagamento</Label>
                    <Input
                      type="date"
                      value={manualForm.data_pagamento}
                      onChange={(e) =>
                        setManualForm({ ...manualForm, data_pagamento: e.target.value })
                      }
                    />
                  </div>
                )}

                <div className="flex gap-3 pt-4">
                  <Button
                    variant="outline"
                    onClick={() => setManualDialogOpen(false)}
                    className="flex-1"
                  >
                    Cancelar
                  </Button>
                  <Button
                    onClick={() => void handleSaveManual()}
                    disabled={
                      savingManual ||
                      !manualForm.fornecedor ||
                      !manualForm.categoria ||
                      !manualForm.valor
                    }
                    className="flex-1 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
                  >
                    {savingManual ? "Salvando..." : "Registrar"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          {selectedLancamento && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
              <Card className="w-full max-w-md border-0 shadow-2xl">
                <CardHeader className="border-b bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-t-xl">
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    Registrar Boleto
                  </CardTitle>
                </CardHeader>

                <CardContent className="pt-6 space-y-4">
                  <div className="p-3 bg-gray-50 rounded-lg text-sm">
                    <p className="font-medium">{selectedLancamento.fornecedor}</p>
                    <p className="text-gray-500">
                      {selectedLancamento.categoria} • Previsto:{" "}
                      {formatCurrency(selectedLancamento.valor_previsto)}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label>Valor Real (R$)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData.valor_real}
                      onChange={(e) =>
                        setFormData({ ...formData, valor_real: e.target.value })
                      }
                      className="border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Data de Vencimento</Label>
                    <Input
                      type="date"
                      value={formData.vencimento_real}
                      onChange={(e) =>
                        setFormData({ ...formData, vencimento_real: e.target.value })
                      }
                      className="border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                    />
                  </div>

                  {divergenciaModal && (
                    <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-center gap-2 text-yellow-700 mb-2">
                        <AlertTriangle className="w-4 h-4" />
                        <span className="font-medium text-sm">Divergência detectada</span>
                      </div>
                      <p className="text-xs text-yellow-600">
                        Diferença de{" "}
                        {formatCurrency(
                          Math.abs(
                            Number.parseFloat(formData.valor_real || "0") -
                              selectedLancamento.valor_previsto
                          )
                        )}
                      </p>
                    </div>
                  )}

                  <div className="flex gap-3 pt-4">
                    <Button
                      variant="outline"
                      onClick={() => setSelectedLancamento(null)}
                      className="flex-1"
                    >
                      Cancelar
                    </Button>
                    <Button
                      onClick={() => void handleSaveBoleto()}
                      disabled={saving || !formData.valor_real || !formData.vencimento_real}
                      className="flex-1 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
                    >
                      {saving ? "Salvando..." : "Confirmar"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          <Dialog open={payDialogOpen} onOpenChange={setPayDialogOpen}>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-green-600" />
                  Confirmar Pagamento
                </DialogTitle>
              </DialogHeader>

              {payingLancamento && (
                <div className="space-y-4 mt-4">
                  <div className="p-3 bg-gray-50 rounded-lg text-sm">
                    <p className="font-medium">{payingLancamento.fornecedor}</p>
                    <p className="text-gray-500">
                      Valor:{" "}
                      {formatCurrency(
                        payingLancamento.valor_real || payingLancamento.valor_previsto
                      )}
                    </p>
                    <p className="text-gray-500">
                      Vencimento: {formatDate(payingLancamento.vencimento_real)}
                    </p>
                  </div>

                  {needsApproval(payingLancamento) && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                      <div className="flex items-center gap-2 text-red-700 mb-2">
                        <ShieldAlert className="w-4 h-4" />
                        <span className="font-medium text-sm">Pagamento acima do limite</span>
                      </div>
                      <p className="text-xs text-red-600 mb-2">
                        Este pagamento excede o limite de{" "}
                        {formatCurrency(empresa?.limite_aprovacao_pagamento || 5000)}. Solicite
                        aprovação do gestor.
                      </p>
                      <a
                        href={generateWhatsAppAprovacao(payingLancamento)}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Button
                          size="sm"
                          variant="outline"
                          className="w-full border-red-300 text-red-700 hover:bg-red-50"
                        >
                          <MessageSquare className="w-3 h-3 mr-2" />
                          Pedir Aprovação via WhatsApp
                        </Button>
                      </a>
                    </div>
                  )}

                  {hasDivergencia(payingLancamento) && (
                    <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-center gap-2 text-yellow-700 mb-2">
                        <AlertTriangle className="w-4 h-4" />
                        <span className="font-medium text-sm">Divergência de valor</span>
                      </div>
                      <p className="text-xs text-yellow-600 mb-2">
                        Previsto: {formatCurrency(payingLancamento.valor_previsto)} | Boleto:{" "}
                        {formatCurrency(payingLancamento.valor_real)}
                      </p>
                      <a
                        href={generateWhatsAppDivergencia(payingLancamento)}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Button
                          size="sm"
                          variant="outline"
                          className="w-full border-yellow-400 text-yellow-700 hover:bg-yellow-50"
                        >
                          <MessageSquare className="w-3 h-3 mr-2" />
                          Notificar Fornecedor via WhatsApp
                        </Button>
                      </a>
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label>Anexar Comprovante de Pagamento</Label>
                    <div className="flex gap-2">
                      <Input
                        type="file"
                        accept="image/*,application/pdf"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            void handleUploadComprovante(file);
                          }
                        }}
                        className="flex-1"
                      />
                    </div>

                    {uploadingComprovante && (
                      <p className="text-xs text-gray-500 flex items-center gap-1">
                        <Loader2 className="w-3 h-3 animate-spin" />
                        Enviando...
                      </p>
                    )}

                    {comprovanteUrl && (
                      <p className="text-xs text-green-600 flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        Comprovante anexado
                      </p>
                    )}
                  </div>

                  <div className="flex gap-3 pt-4">
                    <Button
                      variant="outline"
                      onClick={() => setPayDialogOpen(false)}
                      className="flex-1"
                    >
                      Cancelar
                    </Button>
                    <Button
                      onClick={() => void handlePagar()}
                      disabled={
                        saving ||
                        (needsApproval(payingLancamento) &&
                          !["admin_empresa", "super_admin"].includes(
                            localUser?.nivel_acesso || ""
                          ))
                      }
                      className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                    >
                      {saving ? "Processando..." : "Confirmar Pagamento"}
                    </Button>
                  </div>

                  {comprovanteUrl && (
                    <a
                      href={generateWhatsAppComprovante(payingLancamento)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block"
                    >
                      <Button
                        variant="outline"
                        className="w-full border-green-300 text-green-700 hover:bg-green-50"
                      >
                        <Send className="w-3 h-3 mr-2" />
                        Enviar Comprovante via WhatsApp
                      </Button>
                    </a>
                  )}
                </div>
              )}
            </DialogContent>
          </Dialog>

          <div className="mb-6 flex flex-wrap gap-3 items-center">
            <Button
              onClick={() => setManualDialogOpen(true)}
              className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Lançamento Manual
            </Button>

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={exportarPDF}
                className="border-red-300 text-red-700 hover:bg-red-50 dark:border-red-700 dark:text-red-400 dark:hover:bg-red-900/20"
              >
                <Download className="w-4 h-4 mr-2" />
                PDF
              </Button>

              <Button
                variant="outline"
                onClick={exportarExcel}
                className="border-green-300 text-green-700 hover:bg-green-50 dark:border-green-700 dark:text-green-400 dark:hover:bg-green-900/20"
              >
                <FileSpreadsheet className="w-4 h-4 mr-2" />
                Excel
              </Button>
            </div>
          </div>

          <p className="text-xs text-gray-500 dark:text-gray-400 mb-4 -mt-4">
            Para pagamentos sem provisão: PIX, pagamentos avulsos, custos extras
          </p>

          <Card className="mb-6">
            <CardContent className="pt-4">
              <div className="flex flex-col md:flex-row md:items-end gap-4">
                <div className="flex items-center gap-2 text-gray-700">
                  <Calendar className="w-5 h-5 text-orange-600" />
                  <span className="font-medium">Filtrar por período:</span>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 flex-1">
                  <div className="flex-1">
                    <Label className="text-xs text-gray-500">Data Início</Label>
                    <Input
                      type="date"
                      value={dataInicio}
                      onChange={(e) => setDataInicio(e.target.value)}
                      className="mt-1"
                    />
                  </div>

                  <div className="flex-1">
                    <Label className="text-xs text-gray-500">Data Fim</Label>
                    <Input
                      type="date"
                      value={dataFim}
                      onChange={(e) => setDataFim(e.target.value)}
                      className="mt-1"
                    />
                  </div>

                  {(dataInicio || dataFim) && (
                    <Button variant="outline" onClick={limparFiltroData} className="mt-auto">
                      <Filter className="w-4 h-4 mr-1" />
                      Limpar
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            <Card className="bg-gradient-to-br from-gray-50 to-gray-100 border-gray-200">
              <CardContent className="p-4">
                <p className="text-xs text-gray-500 mb-1">Total Geral</p>
                <p className="text-lg font-bold text-gray-800">
                  {formatCurrency(totaisValores.geral)}
                </p>
                <p className="text-xs text-gray-400">
                  {lancamentosFiltradosPorData.length} lançamentos
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200">
              <CardContent className="p-4">
                <p className="text-xs text-red-600 mb-1">Total Vencido</p>
                <p className="text-lg font-bold text-red-700">
                  {formatCurrency(totaisValores.atrasado)}
                </p>
                <p className="text-xs text-red-400">{totais.atrasado} lançamentos</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
              <CardContent className="p-4">
                <p className="text-xs text-blue-600 mb-1">Total A Pagar</p>
                <p className="text-lg font-bold text-blue-700">
                  {formatCurrency(totaisValores.aPagar)}
                </p>
                <p className="text-xs text-blue-400">{totais.aPagar} lançamentos</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
              <CardContent className="p-4">
                <p className="text-xs text-green-600 mb-1">Total Pago</p>
                <p className="text-lg font-bold text-green-700">
                  {formatCurrency(totaisValores.pago)}
                </p>
                <p className="text-xs text-green-400">{totais.pago} lançamentos</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-8">
            <button
              onClick={() => setFilter("todos")}
              className={`p-4 rounded-xl border-2 transition-all ${
                filter === "todos"
                  ? "border-gray-800 bg-gray-800 text-white"
                  : "border-gray-200 bg-white hover:border-gray-300"
              }`}
            >
              <p className="text-2xl font-bold">{lancamentos.length}</p>
              <p className="text-xs opacity-75">Todos</p>
            </button>

            <button
              onClick={() => setFilter("Aguardando Boleto")}
              className={`p-4 rounded-xl border-2 transition-all ${
                filter === "Aguardando Boleto"
                  ? "border-gray-500 bg-gray-500 text-white"
                  : "border-gray-200 bg-white hover:border-gray-300"
              }`}
            >
              <p className="text-2xl font-bold">{totais.aguardando}</p>
              <p className="text-xs opacity-75">Aguardando</p>
            </button>

            <button
              onClick={() => setFilter("A Pagar")}
              className={`p-4 rounded-xl border-2 transition-all ${
                filter === "A Pagar"
                  ? "border-blue-500 bg-blue-500 text-white"
                  : "border-gray-200 bg-white hover:border-blue-300"
              }`}
            >
              <p className="text-2xl font-bold">{totais.aPagar}</p>
              <p className="text-xs opacity-75">A Pagar</p>
            </button>

            <button
              onClick={() => setFilter("Atrasado")}
              className={`p-4 rounded-xl border-2 transition-all ${
                filter === "Atrasado"
                  ? "border-red-500 bg-red-500 text-white"
                  : "border-gray-200 bg-white hover:border-red-300"
              }`}
            >
              <p className="text-2xl font-bold">{totais.atrasado}</p>
              <p className="text-xs opacity-75">Atrasado</p>
            </button>

            <button
              onClick={() => setFilter("Pago")}
              className={`p-4 rounded-xl border-2 transition-all ${
                filter === "Pago"
                  ? "border-green-500 bg-green-500 text-white"
                  : "border-gray-200 bg-white hover:border-green-300"
              }`}
            >
              <p className="text-2xl font-bold">{totais.pago}</p>
              <p className="text-xs opacity-75">Pago</p>
            </button>
          </div>

          {filteredLancamentos.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Calculator className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p className="text-gray-500">Nenhum lançamento encontrado</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {filteredLancamentos.map((lancamento) => {
                const status = calcularStatus(lancamento);
                const divergencia = hasDivergencia(lancamento);
                const precisaAprovacao = needsApproval(lancamento);

                return (
                  <Card
                    key={lancamento.id}
                    className={divergencia ? "border-yellow-300" : ""}
                  >
                    <CardContent className="p-4">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex items-start gap-4">
                          <div
                            className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                              divergencia ? "bg-yellow-100" : "bg-orange-100"
                            }`}
                          >
                            <Calculator
                              className={`w-6 h-6 ${
                                divergencia ? "text-yellow-600" : "text-orange-600"
                              }`}
                            />
                          </div>

                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h3 className="font-semibold text-gray-800">
                                {lancamento.fornecedor}
                              </h3>
                              {getStatusBadge(lancamento)}

                              {divergencia && status !== "Pago" && (
                                <Badge
                                  variant="outline"
                                  className="bg-yellow-50 text-yellow-700 border-yellow-300"
                                >
                                  <AlertTriangle className="w-3 h-3 mr-1" />
                                  Divergência
                                </Badge>
                              )}

                              {precisaAprovacao && status !== "Pago" && (
                                <Badge
                                  variant="outline"
                                  className="bg-red-50 text-red-700 border-red-300"
                                >
                                  <ShieldAlert className="w-3 h-3 mr-1" />
                                  Aprovação
                                </Badge>
                              )}
                            </div>

                            <p className="text-sm text-gray-500">
                              {formatDate(lancamento.data_pedido)} • {lancamento.categoria}
                            </p>

                            <div className="flex items-center gap-4 mt-1 text-sm flex-wrap">
                              <span className="text-gray-600">
                                Prev:{" "}
                                <span className="font-medium">
                                  {formatCurrency(lancamento.valor_previsto)}
                                </span>
                              </span>

                              {lancamento.valor_real !== null && (
                                <span
                                  className={
                                    divergencia ? "text-yellow-600" : "text-gray-600"
                                  }
                                >
                                  Real:{" "}
                                  <span className="font-medium">
                                    {formatCurrency(lancamento.valor_real)}
                                  </span>
                                </span>
                              )}

                              {lancamento.vencimento_real && (
                                <span className="text-gray-600">
                                  Venc:{" "}
                                  <span className="font-medium">
                                    {formatDate(lancamento.vencimento_real)}
                                  </span>
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0 flex-wrap">
                          {lancamento.anexo_url && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => window.open(lancamento.anexo_url!, "_blank")}
                            >
                              <Image className="w-4 h-4" />
                            </Button>
                          )}

                          {divergencia &&
                            status !== "Pago" &&
                            getFornecedorWhatsApp(lancamento.fornecedor) && (
                              <a
                                href={generateWhatsAppDivergencia(lancamento)}
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="border-yellow-300 text-yellow-700"
                                >
                                  <MessageSquare className="w-4 h-4" />
                                </Button>
                              </a>
                            )}

                          {status === "Aguardando Boleto" && (
                            <Button
                              size="sm"
                              onClick={() => handleDarBaixa(lancamento)}
                              className="bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-700 hover:to-gray-800"
                            >
                              <FileText className="w-4 h-4 mr-1" />
                              Dar Baixa
                            </Button>
                          )}

                          {(status === "A Pagar" || status === "Atrasado") && (
                            <Button
                              size="sm"
                              onClick={() => handleOpenPayDialog(lancamento)}
                              className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                            >
                              <CreditCard className="w-4 h-4 mr-1" />
                              Pagar
                            </Button>
                          )}

                          {status === "Pago" && (
                            <div className="flex items-center gap-2 flex-wrap">
                              <Badge className="bg-green-100 text-green-700 border-green-200">
                                Pago em {formatDate(lancamento.data_pagamento)}
                              </Badge>

                              {getFornecedorWhatsApp(lancamento.fornecedor) && (
                                <a
                                  href={generateWhatsAppComprovante(lancamento)}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                >
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="border-green-300 text-green-700"
                                  >
                                    <Send className="w-4 h-4" />
                                  </Button>
                                </a>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}